#include"groupe.h"
int main(){
    Etudiant Divi=Etudiant("Sequin", "Divi", 2002, 3);
    Divi.affiche();
    groupe classe(3);
    classe.affiche();
}