#include "qq.h"
using namespace std;

/*
Constructeur par défaut d'un rationnel
*/
qq::qq(){
    numerator=0;
    denominator=1;
}

/*
Constructeur avec un int (j'en avais besoin pour le determinant)
*/
qq::qq(int n){
    numerator = n;
    denominator = 1;
}

/*
Entrée : p et q
Retour: p/q
*/
qq::qq(int p, int q){
    if (q == 0) throw std::invalid_argument("Dénominateur nul");
    numerator = p;
    denominator =q;
};

/*
renvoie true ssi q>0
*/
bool qq::signe(){
    return (denominator>0);
};

/*
Corrige la fraction pour que q>0
*/
void qq::signecorrect(){
    if (not this->signe()){
        this->numerator=-this->numerator;
        this->denominator=-this->denominator;
    }
};

/*
Affiche la fraction
*/
void qq::affiche(){
    cout<<numerator<<"/"<<denominator<<endl;
};

/*
Entrée : a et b
Sortie : pgcd de a et b
*/
int qq::pgcd(int a, int b){
    while (b != 0) {
        int r = a % b;
        a = b;
        b = r;
    }
    return a;
};

/*
Donne la fraction réduite avec le dénominateur positif (unique)
*/
void qq::reduction(){
    this->signecorrect();
    int d=pgcd(numerator, denominator);
    numerator = numerator/d;
    denominator = denominator/d;
};

/*
Entrée: n et m
Sortie: ppcm de n et m
*/
int qq::ppcm(int n, int m){
    return n*m/pgcd(n, m);
};

/*
Surchage du *
*/
qq qq::operator*(const qq& frac){
    qq prod =qq((this->numerator)*frac.numerator, (this->denominator)*frac.denominator);
    prod.reduction();
    return prod;
};

/*
Surcharche du +
*/
qq qq::operator+(const qq& frac){
    int newDenominator = ppcm(denominator, frac.denominator);
    qq somme = qq(numerator*newDenominator/denominator + frac.numerator*newDenominator/frac.denominator, newDenominator);
    somme.reduction();
    return somme;
}

/*
Surcharge du /
*/
qq qq::operator/(const qq& frac){
     if (frac.numerator == 0) throw std::invalid_argument("Division par zéro");
    qq prod =qq((this->numerator)*frac.denominator, (this->denominator)*frac.numerator);
    prod.reduction();
    return prod;
};

/*
Surcharge du -
*/
qq qq::operator-(const qq& frac){
    int newDenominator = ppcm(denominator, frac.denominator);
    qq somme = qq(numerator*newDenominator/denominator - frac.numerator*newDenominator/frac.denominator, newDenominator);
    somme.reduction();
    return somme;
};

/*
Surcharge du - unaire
*/
qq qq::operator-() const {
    return qq(-numerator, denominator);
}




/*
Operateur d'affectation
*/
qq& qq::operator&=(const qq &frac){
    numerator=frac.numerator;
    denominator=frac.denominator;
    return *this;
}

/*
Surchage du += pour le determinant encore mais ça a un sens
*/
qq& qq::operator+=(const qq& frac){
    int newDenominator = ppcm(denominator, frac.denominator);
    int newNumerator = numerator*newDenominator/denominator + frac.numerator*newDenominator/frac.denominator;
    numerator = newNumerator;
    denominator = newDenominator;
    reduction();
    return *this;
};

/*
Opérateur de puissance
*/
qq qq::pow(const int n){;
    qq power;  
    if(n<0){
        power = qq( std::pow(this->denominator,(-n)), std::pow(this->numerator,(-n)));
        
    }
    else{
        power = qq(std::pow(this->numerator, n), std::pow(this->denominator, n));
    };
    power.reduction();
    return power;

}
/*
Surcharge du << pour pouvoir ne pas avoir à modifier mes affiche()
*/
ostream& operator<< (ostream &flux, qq const &r) {
    flux<<r.numerator<<"/"<<r.denominator;
    return flux;
}
/*
surcharge du >> pour la lecture
*/
std::istream& operator>>(std::istream& flux, qq& r)
{
    int num, den;
    flux >> num >> den;
    r = qq(num, den);
    return flux;
}

double qq::operator+(const double& d){
    return d + numerator/denominator;
};

double qq::operator*(const double& d){
    return d*numerator/denominator;
};

/*
Opérateurs de comparaison pour qq
Les dénominateurs sont toujours positifs, seuls les numérateurs peuvent être négatifs
*/
bool qq::operator>(const qq& frac) const {
    // a/b > c/d  ⟺  a*d > c*b
    return numerator * frac.denominator > frac.numerator * denominator;
}

bool qq::operator==(const qq& frac) const {
    // a/b == c/d  ⟺  a*d == c*b
    return numerator * frac.denominator == frac.numerator * denominator;
}

bool qq::operator<(const qq& frac) const {
    // a/b < c/d  ⟺  a*d < c*b
    return numerator * frac.denominator < frac.numerator * denominator;
}

/*
Retourne la valeur absolue d'un rationnel
*/
qq qq::abs() const {
    if (numerator < 0) {
        return qq(-numerator, denominator);
    }
    return qq(numerator, denominator);
}